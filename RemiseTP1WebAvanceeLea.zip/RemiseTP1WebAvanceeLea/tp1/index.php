<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Librairie accueil</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
    <nav>
        <a href="livre-list.php" class = 'text-header nav-header'>Livres</a>
        <a href="auteur-list.php" class = 'text-header nav-header'>Auteurs</a>
        <a href="editeur-list.php" class = 'text-header nav-header'>Éditeurs</a>
        <a href="client-list.php" class = 'text-header nav-header'>Clients</a>
    </nav>
</header>
<body>

    
</body>
</html>