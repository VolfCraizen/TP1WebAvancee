<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour récupérer les valeurs de la table
$auteur = $crud->select('auteur');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un livre</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <form action="auteur-store.php" method="post">

        <label>Nom complet
            <input type="text" name="nom">
        </label>
    <!-------------------------------------------->
        <label>Date de naissance
            <input type="date" name="date_de_naissance">
        </label>
    <!-------------------------------------------->

        <input type="submit" value="save">
        
    </form>
    
</body>
</html>