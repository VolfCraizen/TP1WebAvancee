<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour récupérer les valeurs de la table
$editeur = $crud->select('editeur');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un editeur</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <form action="editeur-store.php" method="post">

        <label>Nom
            <input type="text" name="nom">
        </label>

    <!-------------------------------------------->

        <label>Adresse
            <input type="text" name="adresse">
        </label>

    <!-------------------------------------------->

        <label>Telephone    <small>Ex: 555-555-5555</small>
            <input type="text" name="telephone">
        </label>

    <!-------------------------------------------->

        <label>Courriel
            <input type="email" name="courriel">
        </label>

    <!-------------------------------------------->

        <input type="submit" value="save">
        
    </form>
    
</body>
</html>