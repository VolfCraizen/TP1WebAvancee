<?php
require_once('Class/CRUD.php');
$crud = new CRUD;
//Appel la fonction delete pour éffacer les valeurs
$delete = $crud->delete('livre', $_POST['id']);

?>