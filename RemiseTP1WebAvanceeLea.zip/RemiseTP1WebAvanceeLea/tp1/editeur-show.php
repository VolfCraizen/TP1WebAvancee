<!--Montre les livres qu'ils on écrit sur leur page-->

<?php
if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('Classe/CRUD.php');
    $crud = new CRUD;
    //Appel la fonction pour récupérer les valeurs de la table
    $livre = $crud->select('livre');
    //Appel la fonction pour récupérer les valeurs de la table par id
    $editeur = $crud->selectId('editeur', $id);
}else{
    header('location:client-index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails éditeur</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <!-------------------------------------------->

        <h2>Livres publier par <?= $editeur['nom'] ?></h2>

        <?php

        foreach($livre as $row){


            extract($row);  //row actif
     
            $auteur = $crud->selectId('auteur', $Auteur_id);
            $auteur_nom = $auteur['nom'];

            $editeur = $crud->selectId('editeur', $Editeur_id);
            $editeur_id = $editeur['id'];

            if ($row['Editeur_id'] == $editeur_id) {

        ?>

            <div class="livre">
                <h3 class="nom_champ"><?= $row['titre']?></h3>
                <p><strong>Date de publication : </strong><?= $row['date_de_publication']?></p>
                <p><strong>Auteur : </strong><a href="auteur-show.php?id=<?= $row['id']?>"><?= $auteur_nom?></a></p>
            </div>

        <?php
            }
        }
        ?>
</body>