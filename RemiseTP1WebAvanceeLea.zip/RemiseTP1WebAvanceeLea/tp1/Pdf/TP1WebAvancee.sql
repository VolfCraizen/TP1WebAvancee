-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema librairietp1
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema librairietp1
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `librairietp1` DEFAULT CHARACTER SET utf8 ;
USE `librairietp1` ;

-- -----------------------------------------------------
-- Table `librairietp1`.`Editeur`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Editeur` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(50) NOT NULL,
  `adresse` VARCHAR(50) NULL,
  `telephone` VARCHAR(50) NULL,
  `courriel` VARCHAR(50) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `librairietp1`.`Auteur`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Auteur` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(50) NOT NULL,
  `date_de_naissance` DATE NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `librairietp1`.`Livre`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Livre` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `titre` VARCHAR(50) NOT NULL,
  `date_de_publication` DATE NOT NULL,
  `prix` INT NOT NULL,
  `rabais` INT NOT NULL,
  `Editeur_id` INT NOT NULL,
  `Auteur_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Livre_Editeur_idx` (`Editeur_id` ASC),
  INDEX `fk_Livre_Auteur1_idx` (`Auteur_id` ASC),
  CONSTRAINT `fk_Livre_Editeur`
    FOREIGN KEY (`Editeur_id`)
    REFERENCES `librairietp1`.`Editeur` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Livre_Auteur1`
    FOREIGN KEY (`Auteur_id`)
    REFERENCES `librairietp1`.`Auteur` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `librairietp1`.`Client`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Client` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(50) NOT NULL,
  `adresse` VARCHAR(50) NOT NULL,
  `code_postal` VARCHAR(50) NOT NULL,
  `telephone` VARCHAR(50) NULL,
  `courriel` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `librairietp1`.`Facture`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Facture` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `date` DATE NOT NULL,
  `Client_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Facture_Client1_idx` (`Client_id` ASC),
  CONSTRAINT `fk_Facture_Client1`
    FOREIGN KEY (`Client_id`)
    REFERENCES `librairietp1`.`Client` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `librairietp1`.`Facture-Livre`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `librairietp1`.`Facture-Livre` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `qt` INT NOT NULL,
  `Livre_id` INT NOT NULL,
  `Facture_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Facture-Livre_Livre1_idx` (`Livre_id` ASC),
  INDEX `fk_Facture-Livre_Facture1_idx` (`Facture_id` ASC),
  CONSTRAINT `fk_Facture-Livre_Livre1`
    FOREIGN KEY (`Livre_id`)
    REFERENCES `librairietp1`.`Livre` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Facture-Livre_Facture1`
    FOREIGN KEY (`Facture_id`)
    REFERENCES `librairietp1`.`Facture` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
