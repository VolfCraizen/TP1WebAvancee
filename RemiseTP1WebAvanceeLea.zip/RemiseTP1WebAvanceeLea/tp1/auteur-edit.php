<?php
if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('Classe/CRUD.php');
    $crud = new CRUD;
    //Appel la fonction pour récupérer les valeurs de la table avec l'id
    $auteur = $crud->selectId('auteur', $id);
    extract($auteur);
}else{
    //Retour à l'index
    header('location:index.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <form action="auteur-update.php" method="post" >
        <input type="hidden" name="id" value="<?= $id; ?>">
    <!-------------------------------------------->
        <label>Nom
            <input type="text" name="nom" value="<?= $nom; ?>">
        </label>
    <!-------------------------------------------->
        <label>Date de naissance
            <input type="date" name="date_de_naissance" value="<?= $date_de_naissance; ?>">
        </label>
    <!-------------------------------------------->
        <input type="submit" value="save">

    </form>

</body>
</html>