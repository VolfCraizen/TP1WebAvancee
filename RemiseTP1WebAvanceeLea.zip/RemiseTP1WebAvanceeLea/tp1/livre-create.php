<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Récupère les valeurs de la table
$auteur = $crud->select('auteur', 'nom');
//Récupère les valeurs de la table
$editeur = $crud->select('editeur', 'nom');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un livre</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <form action="livre-store.php" method="post">

        <label>Titre
            <input type="text" name="titre" required>
        </label>
    <!-------------------------------------------->
        <label>Date de publication
            <input type="date" name="date_de_publication" required>
        </label>
    <!-------------------------------------------->
        <label>Prix ($)
            <input type="number" step=".01" name="prix" required>
        </label>
    <!-------------------------------------------->
        <label>Rabais (%)
            <input type="number" name="rabais" required>
        </label>
    <!-------------------------------------------->
        <label>Auteur
            <select name="auteur_id">
            <?php
                foreach($auteur as $row){
            ?>
                <option value="<?= $row['id'];?>"><?= $row['nom'];?></option>
            <?php
                }
            ?>
            </select>
        </label>
    <!-------------------------------------------->
        <label>Éditeur
            <select name="editeur_id">
            <?php
                foreach($editeur as $row){
            ?>
                <option value="<?= $row['id'];?>"><?= $row['nom'];?></option>
            <?php
                }
            ?>
            </select>
        </label>
    <!-------------------------------------------->

        <input type="submit" value="save">

    </form>
    
</body>
</html>