<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour inserer les valeurs de la table
$insert = $crud->insert('client', $_POST);
//Retour à la liste des clients
header("location:client-list.php");

?>