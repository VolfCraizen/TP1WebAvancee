<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour récupérer les valeurs de la table
$facture = $crud->select('Facture-Livre');
//Appel la fonction pour récupérer les valeurs de la table

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une facture</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <form action="facture-store.php" method="post">

        <label>Client
            <select name="livre_id">
            <?php
                foreach($livre as $row){
            ?>
                <option value="<?= $row['id'];?>"><?= $row['nom'];?></option>
            <?php
                }
            ?>
            </select>
        </label>

        <input type="submit" value="save">
        
    </form>
    
</body>
</html>