<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour récupérer les valeurs de la table
$auteur = $crud->select('auteur');
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste d'auteur</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
    <nav>
        <a href="livre-list.php" class = 'text-header nav-header'>Livres</a>
        <a href="editeur-list.php" class = 'text-header nav-header'>Éditeurs</a>
        <a href="client-list.php" class = 'text-header nav-header'>Client</a>
    </nav>
</header>

<body>
    <h2>Liste des auteurs</h2>

    <?php
    foreach($auteur as $row){
    ?>
        <div>

            <h3 class="nom_champ"><?= $row['nom']?></h3>
        <!-------------------------------------------->
            <p><strong>Date de naissance : </strong><?= $row['date_de_naissance']?></p>
        <!-------------------------------------------->
            <a href="auteur-edit.php?id=<?= $row['id']?>" class = "button">Modifier</a>
            <a href="auteur-show.php?id=<?= $row['id']?>" class = "button">Détails</a>
        <!-------------------------------------------->    
            <form action="auteur-delete.php" method="post">
                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                <input type="submit" value="Delete">
            </form>

        </div>
        
    <?php
    }
    ?>

<a href="auteur-create.php" class = "button">Ajouter un auteur</a>
    
</body>
</html>
