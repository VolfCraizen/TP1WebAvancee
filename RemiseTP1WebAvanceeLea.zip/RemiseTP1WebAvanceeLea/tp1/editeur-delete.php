<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction delete pour éffacer les valeurs
$delete = $crud->delete('editeur', $_POST['id']);

?>