<?php


require_once('Classe/CRUD.php');

    $crud = new CRUD;
    //Appel la fonction pour récupérer les valeurs de la table
    $livre = $crud->select('livre');

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste d'auteur</title>
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
    <nav>
        <a href="auteur-list.php" class = 'text-header nav-header'>Auteurs</a>
        <a href="editeur-list.php" class = 'text-header nav-header'>Éditeurs</a>
        <a href="client-list.php" class = 'text-header nav-header'>Clients</a>
    </nav>
    <link rel="stylesheet" href="./css/styles.css">
</header>

<body>

        <h2>Livres disponibles</h2>

        <?php

        foreach($livre as $row){
            extract($row);

            $auteur = $crud->selectId('auteur', $Auteur_id);
            $auteur_nom = $auteur['nom'];

            $editeur = $crud->selectId('editeur', $Editeur_id);
            $editeur_nom = $editeur['nom'];

            require_once('Classe/prix-post-rabais.php');
            $calculeRabais = new Rabais;

        ?>

            <div>
                <h3 class="nom_champ"><?= $row['titre']?></h3>
            <!-------------------------------------------->
                <p><strong>Date de publication : </strong><?= $row['date_de_publication']?></p>
                <p><strong>Prix : </strong><?=$prixRabais = $calculeRabais->calculeRabais($row['prix'], $row['rabais'])?> $ après un rabais de <?= $row['rabais']?> % </p>
                <p><strong>Auteur : </strong><a href="auteur-show.php?id=<?= $row['id']?>"><?= $auteur_nom?></a></p>
                <p><strong>Éditeur : </strong><a href="editeur-show.php?id=<?= $row['id']?>"><?= $editeur_nom?></a></p>
            <!-------------------------------------------->
                <a href="facture-create.php?id=<?= $row['id']?>" class = "button">Ajouter aux panier</a>
                <a href="livre-edit.php?id=<?= $row['id']?>" class = "button">Modifier</a>
            <!-------------------------------------------->
                <form action="livre-delete.php" method="post">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>" class = "button"><input type="submit" value="Delete">
                </form>
                
            </div>

        <?php
        }
        ?>
    <a href="livre-create.php" class = "button">Ajouter un livre</a>
    
</body>
</html>