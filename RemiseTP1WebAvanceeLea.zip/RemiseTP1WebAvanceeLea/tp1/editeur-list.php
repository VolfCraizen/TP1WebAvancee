<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour récupérer les valeurs de la table
$editeur = $crud->select('editeur');

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste d'éditeur</title>
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
    <nav>
        <a href="livre-list.php" class = 'text-header nav-header'>Livres</a>
        <a href="auteur-list.php" class = 'text-header nav-header'>Auteurs</a>
        <a href="client-list.php" class = 'text-header nav-header'>Clients</a>
    </nav>
    <link rel="stylesheet" href="./css/styles.css">
</header>

<body>

    <!-------------------------------------------->
        <h2>Liste des éditeurs</h2>

        <?php
        foreach($editeur as $row){
        ?>

            <div class="espace_data auteur">

                <h3 class="nom_champ"><?= $row['nom']?></h3>
            <!-------------------------------------------->
                <p><strong>Adresse : </strong><?= $row['adresse']?></p>
                <p><strong>Telephone : </strong><?= $row['telephone']?></p>
                <p><strong>Courriel : </strong><?= $row['courriel']?></p>
            <!-------------------------------------------->
                <a href="editeur-edit.php?id=<?= $row['id']?>" class = "button">Modifier</a>
            <!-------------------------------------------->
                <form action="editeur-delete.php" method="post">
                    <input type="hidden" name="id" value="<?= $row['id'] ?>">
                    <br>
                    <input type="submit" value="Delete">
                </form>

            </div>

        <?php
        }
        ?>

    <a href="editeur-create.php" class = "button">Ajouter un éditeur</a>
    
</body>
</html>
