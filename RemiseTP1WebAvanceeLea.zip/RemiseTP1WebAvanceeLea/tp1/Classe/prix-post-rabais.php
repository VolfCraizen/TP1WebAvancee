<?php

class Rabais extends PDO {

    public function __construct(){
        parent::__construct('mysql:host=localhost; dbname=librairietp1; port=3306; charset=utf8', 'root', '');
    }


    //Calcule le prix du livre après le rabais
    //----------------------------------------------------------------
    function calculeRabais($prix, $rabais){
        $prixFinal = $prix - ($prix * $rabais/100);

        return $prixFinal;
    }

}