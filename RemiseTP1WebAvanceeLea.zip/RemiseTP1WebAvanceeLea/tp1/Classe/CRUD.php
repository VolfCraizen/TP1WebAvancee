<?php

class CRUD extends PDO {

    public function __construct(){
        parent::__construct('mysql:host=localhost; dbname=librairietp1; port=3306; charset=utf8', 'root', '');
    }

    //Selectionne les valeurs des tables
    //----------------------------------------------------------------
    public function select($table, $field='id', $order='ASC'){
        $sql="SELECT * FROM $table ORDER BY $field $order";
        $stmt = $this->query($sql);
        return $stmt->fetchAll();
    }



    //Selectionne les valeurs des tables avec l'Id
    //----------------------------------------------------------------
    public function selectId($table, $value, $field = 'id'){
        $sql="SELECT * FROM $table WHERE $field = '$value'";
        $stmt = $this->query($sql);
        $count = $stmt->rowCount();
        if($count == 1){
            return $stmt->fetch();
        }else{
            echo $value;
            die();
            header('location:index.php');
        } 
    }



    //Insert les valeurs dans la DB
    //----------------------------------------------------------------
    public function insert($table, $data){

        $nomChamp = implode(", ",array_keys($data));
        $valeurChamp = ":".implode(", :", array_keys($data));

        $sql = "INSERT INTO $table ($nomChamp) VALUES ($valeurChamp)";
        $stmt = $this->prepare($sql);
        foreach($data as $key => $value){
            $stmt->bindValue(":$key", $value);
        }
        $stmt->execute();

        return $this->lastInsertId();

    }



    //Éfface les valeurs dans la DB
    //----------------------------------------------------------------
    public function delete($table, $value, $field = 'id'){

        $sql = "DELETE FROM $table WHERE $field = :$field";
        $stmt = $this->prepare($sql);
        $stmt->bindValue(":$field", $value);
        $stmt->execute();
        header('location:' . $table . '-list.php');
    }



    //Mets à jours les valeurs dans la DB
    //----------------------------------------------------------------
    public function update($table, $data, $field='id'){
      
        $queryField = null;
        foreach($data as $key=>$value){
            $queryField .="$key =:$key, ";
        }
        $queryField = rtrim($queryField, ", ");
        
        $sql = "UPDATE $table SET $queryField WHERE $field = :$field";

        $stmt = $this->prepare($sql);
        foreach($data as $key => $value){
            $stmt->bindValue(":$key", $value);
        }
        $stmt->execute();

        header('Location:' . $table . '-list.php');

    }

}


?>