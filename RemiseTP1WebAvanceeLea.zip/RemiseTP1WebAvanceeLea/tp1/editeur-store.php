<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour inserer les valeurs de la table
$insert = $crud->insert('editeur', $_POST);

header("location:editeur-list.php");

?>