<?php
if(isset($_GET['id']) && $_GET['id']!=null ){
    $id= $_GET['id'];
    require_once('Classe/CRUD.php');
    $crud = new CRUD;
    //Appel la fonction pour récupérer les valeurs de la table
    $livre = $crud->select('livre');
    //Appel la fonction pour récupérer les valeurs de la table par id
    $auteur = $crud->selectId('auteur', $id);
}else{
    //Retour à l'index
    header('location:index.php');
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails auteur</title>
    <link rel="stylesheet" href="./css/styles.css">
</head>

<header>
    <h1><a href="index.php" class="logo">TP1</a></h1>
</header>

<body>

    <div>
        <h2><?= $auteur['nom'] ?></h2>
        <p><strong>Date de naissance : </strong> <?= $auteur['date_de_naissance']?></p>
    </div>

    <h2>Livres écrits par <?= $auteur['nom'] ?></h2>

    <?php

    //Déclaration de L'id de l'auteur pour la vérification des id (À ne pas confondre avec $Auteur_id de livre)
    $auteur_id = $auteur['id'];

    foreach($livre as $row){

        extract($row);
        //Appel la fonction pour récupérer les valeurs de la table par id
        $auteur = $crud->selectId('auteur', $Auteur_id);
        //Appel la fonction pour récupérer les valeurs de la table par id
        $editeur = $crud->selectId('editeur', $Editeur_id);
        $editeur_nom = $editeur['nom'];


        //Vérification des ID
        if ($row['Auteur_id'] == $auteur_id) {

    ?>

    <div class="livre">

        <h3 class="nom_champ"><?= $row['titre']?></h3>

        <p><strong>Date de publication : </strong><?= $row['date_de_publication']?></p>
        <p><strong>Éditeur : </strong><a href="editeur-show.php?id=<?= $row['id']?>"><?= $editeur_nom?></a></p>

    </div>

    <?php
        }
    }
    ?>
</body>