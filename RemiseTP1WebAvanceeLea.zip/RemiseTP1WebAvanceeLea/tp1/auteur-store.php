<?php
require_once('Classe/CRUD.php');
$crud = new CRUD;
//Appel la fonction pour inserer les valeurs de la table
$insert = $crud->insert('auteur', $_POST);
//Retour à la liste d'auteurs
header("location:auteur-list.php");

?>