<?php

require_once('Classe/CRUD.php');
$crud = new crud;
//Appel la fonction pour mettre à jour les valeurs de la table
$update = $crud->update('livre', $_POST);

?>